import numpy
numpy.linspace